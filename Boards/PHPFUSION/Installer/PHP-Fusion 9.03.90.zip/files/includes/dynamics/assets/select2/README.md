Other languages you can find here: https://github.com/select2/select2/tree/stable/3.5
